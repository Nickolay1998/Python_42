import math
##try:
##    print(math.factorial(int(input("Number "))))
##except ValueError:
##    print("Negative number")

##def factorial_func(x):
##    try:
##        return math.factorial(x)
##    except ValueError:
##        return "Negative number"
##
##print(factorial_func(-5))

##
##def factorial_func(x):
##    return math.factorial(x)
##
##x = int(input("Number "))
##    
##try:    
##    print(factorial_func(x))
##except:
##    print("Negative number")


##x = input()
##gl = [int(i) for i in x.split()]
##print("List: ",gl)
##print("Max: ",max(gl))
##print("Min: ",min(gl))
##gl.pop(2)
##print(gl)
##y = int(input("Index: "))
##try:
##    print(gl[y])
##except IndexError:
##    print("IndexError")


##def listf():   
##    gl = [int(i) for i in x.split()]
##    return gl
##x = input("Nums ")
##y = int(input("Index: "))
##l = listf()
##print("List:",l)
##print("Max:",max(l))
##print("Min:",min(l))
##l.pop(y)
##print("List:",l)
##try:
##    print("Total:",l[y])
##except IndexError:
##    print("IndexError")    

##def listf():
##    x = input("Nums ")
##    y = int(input("Index: "))
##    gl = [int(i) for i in x.split()]
##    print("List: ",gl)
##    print("Max: ",max(gl))
##    print("Min: ",min(gl))
##    gl.pop(y)
##    print(gl)
##    try:
##        print(gl[y])
##    except IndexError:
##        print("IndexError")    
##listf()


    
